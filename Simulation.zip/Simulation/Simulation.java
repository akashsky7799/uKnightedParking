
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Backup 
{
	public static void main (String args[])
	{
		try {
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://209.131.253.72:3306/uknightparkingdb";
		String username = "testUser";
		String password = "12345";
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,username,password);
		String sql = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		
		while (true)
		{
			Scanner input = new Scanner(System.in);
			int code = input.nextInt();
			System.out.println();
			
			
			if (code == 1)
			{
				sql = "update Parking set openspots = openspots+1 where name = 'A'";
				statement = con.prepareStatement(sql);
				statement.executeUpdate();
			}
			
			if (code == 2)
			{
				sql = "update Parking set openspots = openspots-1 where name = 'A'";
				statement = con.prepareStatement(sql);
				statement.executeUpdate();
			}
			
			if (code == 3)
			{
				sql = "select * from Parking";
				statement = con.prepareStatement(sql);
				rs = statement.executeQuery();
				while (rs.next())
				System.out.println(rs.getString("name") + "  "+ rs.getInt("openspots"));
			}
			
			if (code == 4)
			{
				sql = "update Parking set openspots = 1100 where name = 'A'";
				statement = con.prepareStatement(sql);
				statement.executeUpdate();
				sql = "update Parking set openspots = 1200 where name = 'B'";
				statement = con.prepareStatement(sql);
				statement.executeUpdate();
				sql = "update Parking set openspots = 1300 where name = 'C'";
				statement = con.prepareStatement(sql);
				statement.executeUpdate();
			}
		
		}
		}
		catch (Exception e) {
			
		}
	}

}
