package parking;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShowData
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/ShowData")
public class ShowData extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ShowData() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
    	
    	try {
String driver = "com.mysql.jdbc.Driver";
			
			String url = "jdbc:mysql://209.131.253.72:3306/uknightparkingdb";
			String username = "testUser";
			String password = "12345";
			Class.forName(driver);
			Connection con = DriverManager.getConnection(url,username,password);
			String sql = "select * from Parking";
			PreparedStatement statement = con.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			
			
			ArrayList list = new ArrayList();
			
			while (rs.next())
			{
				Map data = new HashMap();
				data.put("name", rs.getString("name"));
				data.put("openspots", rs.getInt("openspots"));
				list.add(data);
			}
			request.setAttribute("list", list);
			
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    	request.getRequestDispatcher("display.jsp").forward(request,response);
    	return;
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		request.getRequestDispatcher("display.jsp").forward(request,response);
	}

}
